# 🔄 End-to-End Data Flow Documentation

## Complete System Data Flow

### 1. Frontend: User Interaction
**Location:** `frontend/index.html` + `frontend/app.js`

```
User clicks map → Marker placed → Circle drawn → "Analyze" button
```

**Data collected:**
- `latitude`: Clicked location's latitude (e.g., 39.90923)
- `longitude`: Clicked location's longitude (e.g., 116.397428)
- `radius`: User-configured radius in meters (default 500m, range 100-5000m)

**API Request:**
```javascript
POST http://localhost:5000/api/analyze
Content-Type: application/json

{
  "latitude": 39.90923,
  "longitude": 116.397428,
  "radius": 500
}
```

---

### 2. Backend: API Endpoint
**Location:** `backend/app.py` - `/api/analyze` endpoint

**Flow:**
```python
1. Receive request (lat, lng, radius)
2. Validate input parameters
3. Call AMap service functions
4. Extract features from map data
5. Call AI model for prediction
6. Calculate final Feng Shui score
7. Return JSON response
```

**Code:**
```python
# Step 1: Fetch real POI data from AMap API
poi_data = search_nearby_pois(longitude, latitude, radius)

# Step 2: Fetch real road network data
road_data = get_road_network_data(longitude, latitude, radius)

# Step 3: Extract dynamic features
features = extract_features(poi_data, road_data, longitude, latitude, radius)

# Step 4: Calculate comprehensive score
result = calculate_feng_shui_score(features)
```

---

### 3. AMap Service Layer
**Location:** `backend/amap_service.py`

#### Function: `search_nearby_pois(longitude, latitude, radius)`

**What it does:**
- Makes REAL HTTP requests to AMap POI Search API
- Searches for 8 POI categories within the radius:
  - Parks & green spaces
  - Water bodies (rivers, lakes)
  - Commercial buildings
  - Residential areas
  - Transportation facilities
  - Hospitals
  - Schools
  - Temples & religious sites

**Returns:**
```python
{
  'parks': [
    {'name': '奥林匹克森林公园', 'distance': 234.5, 'longitude': 116.xxx, 'latitude': 40.xxx},
    ...
  ],
  'water': [...],
  'buildings': [...],
  ...
}
```

#### Function: `get_road_network_data(longitude, latitude, radius)`

**What it does:**
- Fetches road and intersection data from AMap
- Parses road features and extracts intersection points

**Returns:**
```python
{
  'roads': [{'name': '某某路', 'longitude': xxx, 'latitude': xxx}, ...],
  'intersections': [{'name': '某某路口', 'longitude': xxx, 'latitude': xxx}, ...],
  'road_count': 12
}
```

---

### 4. Feature Extraction
**Location:** `backend/feature_extractor.py`

#### Main Function: `extract_features(poi_data, road_data, longitude, latitude, radius)`

**All calculations are DYNAMIC - no hardcoded values!**

#### Feature 1: `green_area_ratio`
**Algorithm:**
- Takes REAL park POIs from AMap
- Estimates area based on distance (closer = more accurate)
- Uses distance-weighted calculation
- Formula: `total_green_area / (π × radius²)`

**Example:**
```
Input: 5 parks at distances [150m, 300m, 450m, 600m, 800m]
Process:
  - Park 1 (150m): estimated 45,000 m² × weight
  - Park 2 (300m): estimated 30,000 m² × weight
  - ...
Output: green_area_ratio = 0.156
```

#### Feature 2: `water_proximity`
**Algorithm:**
- Finds closest water body from REAL AMap data
- Applies Feng Shui distance curve:
  - < 100m: Too close (0.5-1.0)
  - 100-800m: Optimal (0.85-1.0)
  - 800-1500m: Moderate (0.35-0.85)
  - > 1500m: Far (0.0-0.35)

**Example:**
```
Input: Water bodies at [423m, 850m, 1200m]
Closest: 423m
Result: water_proximity = 0.98 (optimal range)
```

#### Feature 3: `building_density`
**Algorithm:**
- Counts REAL buildings (commercial + residential)
- Calculates density per km²
- Normalizes using sigmoid function

**Example:**
```
Input: 87 buildings in 500m radius
Area: 0.785 km²
Density: 110.8 buildings/km²
Output: building_density = 0.23
```

#### Feature 4: `road_intersection_density`
**Algorithm:**
- Counts REAL intersections from road data
- Calculates density per km²
- Applies optimal range scoring (10-20 intersections/km² is best)

**Example:**
```
Input: 15 intersections in 500m radius
Area: 0.785 km²
Density: 19.1 intersections/km²
Output: road_intersection_density = 0.95 (optimal)
```

#### Feature 5: `orientation_score`
**Algorithm:**
- For each building POI:
  - Calculate bearing from center point
  - Convert to compass angle (0-360°)
  - Score based on Feng Shui (south = best)
  - Weight by distance (closer = more important)
- Average all weighted scores

**Example:**
```
Input: 50 buildings with various positions
Calculations:
  - Building A: bearing 175° (south) → score 0.99
  - Building B: bearing 310° (northwest) → score 0.42
  - ...
Weighted average: 0.67
Output: orientation_score = 0.67
```

#### Feature 6: `environmental_quality`
**Algorithm:**
- Counts REAL hospitals and schools
- Optimal: 1-3 hospitals, 3-5 schools
- Too many or too few reduces score

**Example:**
```
Input: 2 hospitals, 4 schools
Hospital score: 1.0 (optimal)
School score: 1.0 (optimal)
Output: environmental_quality = 1.0
```

#### Feature 7: `spiritual_presence`
**Algorithm:**
- Counts REAL temples/religious sites
- Optimal: 1-2 temples nearby

**Example:**
```
Input: 1 temple at 650m
Output: spiritual_presence = 0.5
```

#### Feature 8: `qi_flow` (Derived)
**Algorithm:**
- Combines road connectivity + openness + green space
- `qi_flow = 0.3×road_score + 0.4×(1-building_density) + 0.3×green_ratio`

**Example:**
```
Input:
  - 12 roads (road_score = 0.90)
  - building_density = 0.23 (openness = 0.77)
  - green_ratio = 0.156
Output: qi_flow = 0.27 + 0.31 + 0.05 = 0.63
```

---

### 5. AI Model Prediction
**Location:** `backend/ai_model.py`

#### Function: `predict_feng_shui_score(features)`

**What it does:**
- Loads trained Random Forest model
- Takes 7 features as input
- Predicts Feng Shui score (0-100)
- Extracts feature importance for explainability

**Example:**
```python
Input features:
{
  'green_area_ratio': 0.156,
  'water_proximity': 0.98,
  'building_density': 0.23,
  'road_intersection_density': 0.95,
  'orientation_score': 0.67,
  'environmental_quality': 1.0,
  'spiritual_presence': 0.5
}

AI Prediction: 73.8
Feature Importance:
  1. water_proximity: 24%
  2. environmental_quality: 19%
  3. building_density: 16%
  ...
```

---

### 6. Final Scoring
**Location:** `backend/scorer.py`

#### Function: `calculate_feng_shui_score(features)`

**What it does:**
1. Calculates 7 category scores (0-100 each)
2. Calculates Yin-Yang balance
3. Calculates Five Elements harmony
4. Calculates Qi flow score
5. Gets AI prediction
6. Combines: `final = 0.7×traditional + 0.3×AI`
7. Generates explanations and suggestions

**Example:**
```python
Category Scores:
  - green_space: 52.0
  - water_element: 98.0
  - building_harmony: 77.0
  - road_accessibility: 95.0
  - orientation: 67.0
  - environment: 100.0
  - spiritual_energy: 50.0

Traditional score: 75.2
AI score: 73.8
Final score: 0.7×75.2 + 0.3×73.8 = 74.8

Yin-Yang balance: 68.3
Five Elements: {wood: 52, fire: 67, earth: 77, metal: 95, water: 98}
Qi flow: 63.0
```

---

### 7. Response Generation
**Location:** `backend/app.py`

**JSON Response:**
```json
{
  "final_score": 74.8,
  "traditional_score": 75.2,
  "ai_score": 73.8,
  "category_scores": {
    "green_space": 52.0,
    "water_element": 98.0,
    "building_harmony": 77.0,
    "road_accessibility": 95.0,
    "orientation": 67.0,
    "environment": 100.0,
    "spiritual_energy": 50.0,
    "yin_yang_balance": 68.3,
    "five_elements_harmony": 77.8,
    "qi_flow": 63.0
  },
  "five_elements": {
    "wood": 52.0,
    "fire": 67.0,
    "earth": 77.0,
    "metal": 95.0,
    "water": 98.0,
    "overall_score": 77.8
  },
  "yin_yang_balance": 68.3,
  "qi_flow_score": 63.0,
  "explanations": [
    "✨ This location has good Feng Shui with favorable environmental balance.",
    "🌳 Moderate green space presence (52/100) provides adequate natural balance.",
    "💧 Water element is well-positioned (98/100), bringing prosperity and wealth energy.",
    ...
  ],
  "suggestions": [
    "🌱 Increase greenery: Add indoor plants, visit nearby parks regularly...",
    "🏢 Improve space harmony: Use mirrors to create sense of openness...",
    ...
  ],
  "location": {
    "latitude": 39.90923,
    "longitude": 116.397428,
    "radius": 500
  }
}
```

---

### 8. Frontend: Dashboard Display
**Location:** `frontend/app.js` - `displayResults(data)`

**What it does:**
1. Receives JSON response
2. Extracts all scores and data
3. Renders dashboard components:
   - Large score circle (color-coded)
   - 3 metric cards (Yin-Yang, Qi Flow, Five Elements)
   - Radar chart for Five Elements (Chart.js)
   - Horizontal bar chart for categories
   - List of explanations
   - List of suggestions

**Visual output:**
- Score 74.8 displayed in blue circle (good range)
- Charts show visual breakdown
- Explanations explain why
- Suggestions tell how to improve

---

## Key Points: NO HARDCODED VALUES!

✅ **Every calculation uses real AMap data**
- Parks, water, buildings, roads - all from API

✅ **Every feature varies by location**
- Click Beijing city center → different from suburbs
- Click near water → higher water_proximity
- Click dense downtown → higher building_density

✅ **Dynamic radius**
- 500m radius → different POIs than 2000m radius
- All calculations scale with radius

✅ **Real-time processing**
- Each click triggers fresh API calls
- No caching (can add later for optimization)
- Every analysis is location-specific

---

## Example: Two Different Locations

### Location A: Beijing City Center (Tiananmen)
```
Coordinates: (39.90923, 116.397428)
Radius: 500m

AMap Returns:
  - 0 parks (dense urban)
  - 0 water bodies
  - 142 buildings (very dense)
  - 23 intersections (busy)
  - 1 hospital, 0 schools
  - 3 temples

Features:
  - green_area_ratio: 0.02 (very low)
  - water_proximity: 0.0 (none nearby)
  - building_density: 0.85 (very high)
  - road_intersection_density: 0.98 (very high)
  - orientation_score: 0.55 (mixed)
  - environmental_quality: 0.25 (low)
  - spiritual_presence: 1.0 (high)

Final Score: 58.3 (average)
```

### Location B: Olympic Forest Park
```
Coordinates: (40.00, 116.38)
Radius: 500m

AMap Returns:
  - 3 large parks
  - 1 lake
  - 15 buildings (low density)
  - 5 intersections (quiet)
  - 0 hospitals, 1 school
  - 0 temples

Features:
  - green_area_ratio: 0.65 (excellent!)
  - water_proximity: 0.95 (optimal)
  - building_density: 0.15 (low)
  - road_intersection_density: 0.35 (quiet)
  - orientation_score: 0.70 (good)
  - environmental_quality: 0.20 (low services)
  - spiritual_presence: 0.0 (none)

Final Score: 78.5 (good)
```

**Both scores are completely different because the locations are different!**

---

## Testing the System

1. **Open frontend** → Map loads
2. **Click Location A** (downtown) → Analysis runs → Score X
3. **Click Location B** (park area) → Analysis runs → Score Y
4. **Score X ≠ Score Y** ✅ (proves it's dynamic!)
5. **Check browser console** → See logs of API calls and feature values
6. **Check backend terminal** → See detailed feature extraction logs

Every click = new analysis = different results!

---

**🎉 The system is fully dynamic and location-aware!**
