# Quick Start Guide - Feng Shui AI System

## 🚀 Quick Setup (5 minutes)

### Step 1: Get AMap API Keys
1. Visit [AMap Console](https://console.amap.com/)
2. Register/Login
3. Create a new application (Web JS API)
4. Get your **API Key** and **Security Key (SecurityJsCode)**

### Step 2: Configure Backend
```bash
cd backend

# Create .env file
echo "AMAP_API_KEY=your_api_key" > .env
echo "AMAP_SECURITY_KEY=your_security_key" >> .env
echo "DEBUG=True" >> .env

# Install dependencies
pip install -r requirements.txt

# Train AI model
python train_model.py

# Start server
python app.py
```

### Step 3: Configure Frontend
Edit `frontend/index.html` line 11 and 15:
```javascript
securityJsCode: 'YOUR_SECURITY_KEY'  // Replace this
```
```html
key=YOUR_AMAP_KEY  // Replace this
```

### Step 4: Run
Open `frontend/index.html` in your browser!

## 🎯 Test the System

1. **Click on the map** - Try Beijing (default center)
2. **Adjust radius** - Try 500m, 1000m, 2000m
3. **Click "Analyze Location"** - Wait for results
4. **View Dashboard** - See scores, charts, and suggestions

## 🧪 Expected Results

For a typical urban location, you should see:
- **Final Score**: 50-80
- **Category Breakdown**: Visual bar chart
- **Five Elements**: Radar chart
- **Yin-Yang Balance**: 40-80
- **Explanations**: 5-10 insights
- **Suggestions**: 3-8 recommendations

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check Python version
python --version  # Should be 3.8+

# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

### Frontend shows errors
- Check browser console (F12)
- Verify AMap keys are correct
- Ensure backend is running (http://localhost:5000/health)

### No map displayed
- Check AMap API key validity
- Verify Security Key is set correctly
- Check browser console for errors

### Model not training
```bash
cd backend
python train_model.py

# Should see:
# Training Complete!
# R² Score: 0.9XX
```

## 📊 API Testing

Test backend directly:
```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"latitude": 39.90923, "longitude": 116.397428, "radius": 500}'
```

## 🎨 Customization

### Change Default Location
Edit `frontend/app.js` line 16:
```javascript
const defaultCenter = [116.397428, 39.90923]; // [longitude, latitude]
```

### Adjust Feature Weights
Edit `backend/config.py` lines 40-48:
```python
FEATURE_WEIGHTS = {
    'green_area_ratio': 0.20,  # Increase for more green space importance
    'water_proximity': 0.15,
    # ...
}
```

### Change Color Scheme
Edit `frontend/styles.css` - search for color codes like `#667eea`

## 📝 Next Steps

1. **Customize POI Categories** - Add/remove in `config.py`
2. **Enhance AI Model** - Retrain with more samples
3. **Add More Features** - Extend feature extraction
4. **Improve UI** - Add animations, tooltips
5. **Deploy** - Use AWS, Heroku, or Vercel

## 🆘 Support

Check:
- `README.md` for detailed documentation
- Backend logs for error messages
- Browser console for frontend issues

## ✅ Checklist

- [ ] AMap keys configured
- [ ] Backend dependencies installed
- [ ] AI model trained
- [ ] Backend server running
- [ ] Frontend keys configured
- [ ] Browser opened to frontend
- [ ] Map displayed correctly
- [ ] Analysis working

---

**Enjoy analyzing Feng Shui! 🌿✨**
