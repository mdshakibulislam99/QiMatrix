# 🚀 Indoor Feng Shui Analysis - Quick Start Guide

## ⚡ Get Started in 30 Seconds!

### Option 1: Direct Open (Easiest)
```
Just double-click: frontend/indoor-analysis-new.html
```

### Option 2: Local Server
```bash
cd frontend
python -m http.server 8000
# Open: http://localhost:8000/indoor-analysis-new.html
```

---

## 🎯 Two Modes to Choose From

### 🎨 Design Mode
**Perfect for:** Planning new rooms, redesigning spaces

**How it works:**
1. Click "Design Your Room"
2. Drag elements from left panel (30+ items!)
3. Drop them on the canvas
4. Position where you want
5. Click "Analyze Room"
6. Get instant feng shui score!

**Elements Available:**
- 🛏️ Furniture: Bed, Sofa, Desk, Table, Chair, Wardrobe, Bookshelf, TV
- 🖼️ Decor: Mirror, Painting, Clock, Vase, Rug, Curtains, Door, Window
- 🪴 Plants: Bamboo, Plants, Bonsai, Flowers
- 💡 Lighting: Lamp, Chandelier, Candles
- ⛲ Special: Fountain, Crystals

### 📸 Upload Mode
**Perfect for:** Analyzing existing rooms

**How it works:**
1. Click "Upload Room Photos"
2. Take photos from 5 directions:
   - North view
   - South view
   - East view
   - West view
   - Floor plan (overhead)
3. Upload at least 3 photos
4. Click "Analyze Room"
5. AI analyzes your space!

---

## 💯 Understanding Your Score

### Overall Score (0-100):
- **90-100** = Excellent! 🌟
- **75-89** = Good ✅
- **60-74** = Fair ⚠️
- **0-59** = Needs Work 🔧

### What's Analyzed:
1. **Five Elements Balance** (30%)
   - Wood, Fire, Earth, Metal, Water distribution

2. **Yin-Yang Energy** (25%)
   - Passive vs Active energy balance

3. **Space Flow** (25%)
   - Clutter assessment, energy circulation

4. **Functional Layout** (20%)
   - Room-specific requirements met

---

## 💡 Tips for Best Results

### Design Mode Tips:
✅ **Balance Elements**: Include all 5 elements (wood, fire, earth, metal, water)
✅ **Don't Overcrowd**: 10-15 items is ideal
✅ **Room-Specific**: Add appropriate items (bed for bedroom, desk for office)
✅ **Avoid Bad Feng Shui**: Don't place mirror facing bed

### Upload Mode Tips:
✅ **Good Lighting**: Take photos in daylight
✅ **Clear View**: Show entire room from each angle
✅ **All Angles**: Upload all 5 directions for best analysis
✅ **High Quality**: Clear, in-focus photos work best

---

## 🎨 Design Mode Shortcuts

### Left Panel:
- **Search**: Type to find elements
- **Categories**: Click to filter (All, Furniture, Decor, Plants, Lighting)

### Canvas:
- **Drag**: Place elements
- **Click**: Move placed items
- **X Button**: Remove item
- **Clear All**: Start over

### Right Panel:
- See all placed items
- Quick remove buttons
- Item count

---

## 📸 Upload Mode Guide

### Required Photos:
1. **North**: Stand in center, face north wall
2. **South**: Stand in center, face south wall
3. **East**: Stand in center, face east wall
4. **West**: Stand in center, face west wall
5. **Floor**: Take from above (optional but helpful)

### Photo Tips:
- Use smartphone or camera
- Natural lighting preferred
- Capture entire view
- Include all furniture
- Clear, not blurry

---

## 🎯 Common Scenarios

### Scenario 1: Bedroom Design
```
1. Select "Design Mode"
2. Add: Bed, Nightstand, Lamp, Plant, Curtains
3. Avoid: Mirror facing bed
4. Analyze
5. Follow recommendations
```

### Scenario 2: Home Office
```
1. Select "Design Mode"
2. Add: Desk, Chair, Bookshelf, Plant, Lamp
3. Position: Desk in power position
4. Analyze
5. Optimize layout
```

### Scenario 3: Existing Room
```
1. Select "Upload Mode"
2. Take 5 photos (N, S, E, W, Floor)
3. Upload all
4. Analyze
5. Get AI recommendations
```

---

## 🏆 What You'll Get

### Analysis Results:
- ✅ Overall feng shui score
- ✅ Element balance breakdown
- ✅ Energy (yin-yang) assessment
- ✅ Space flow rating
- ✅ Functional layout score

### Recommendations:
- 💡 What to add
- 💡 What to remove
- 💡 How to rearrange
- 💡 Element balancing tips
- 💡 Room-specific advice

---

## 🔥 Pro Tips

### Maximize Your Score:
1. **Include All Elements**: Have wood, fire, earth, metal, water
2. **Balance Energy**: Mix yin (soft) and yang (active) items
3. **Avoid Clutter**: Less is more (10-15 items ideal)
4. **Room Purpose**: Match items to room type
5. **Follow Recommendations**: They're customized for you!

### Feng Shui Basics:
- **Wood** = Growth, health (plants, furniture)
- **Fire** = Passion, fame (lights, red colors)
- **Earth** = Stability, grounding (pottery, earth tones)
- **Metal** = Clarity, precision (clocks, metal frames)
- **Water** = Flow, wealth (fountains, mirrors)

---

## 📱 Mobile Usage

Works perfectly on:
- ✅ Smartphones
- ✅ Tablets
- ✅ Desktops
- ✅ Laptops

Just open the HTML file in any modern browser!

---

## 🎉 You're Ready!

1. **Open** indoor-analysis-new.html
2. **Choose** Design or Upload mode
3. **Create** or upload your room
4. **Analyze** with one click
5. **Improve** with recommendations

**Time to create your perfect feng shui space!** 🏠✨

---

## 🆘 Quick Troubleshooting

**Q: Elements won't drag?**
A: Make sure you're clicking and holding on the element

**Q: Can't analyze?**
A: Design mode: Place at least 1 element
   Upload mode: Upload at least 3 photos

**Q: Want to start over?**
A: Click "Back to Selection" or "Clear All"

**Q: How do I remove an item?**
A: Click the × button on the element

**Q: Where are my results?**
A: Scroll down after clicking "Analyze Room"

---

**Happy Feng Shui-ing!** 🧘‍♀️🌟

*For complete documentation, see: INDOOR_SYSTEM_DOCUMENTATION.md*
