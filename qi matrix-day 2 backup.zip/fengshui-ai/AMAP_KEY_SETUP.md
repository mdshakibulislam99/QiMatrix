# 🔑 AMap API Key Configuration Guide

## Problem: USERKEY_PLAT_NOMATCH Error

The error you're seeing means **you need DIFFERENT API keys** for frontend and backend:

### Frontend (index.html)
- **Needs:** Web JS API key
- **Used for:** Map display in browser
- ✅ Already configured correctly

### Backend (Python/Flask)
- **Needs:** Web Service API key  
- **Used for:** POI search, geocoding, road data
- ❌ Currently using wrong key type

---

## Solution: Get Web Service API Keys

### Step 1: Go to AMap Console
Visit: https://console.amap.com/dev/key/app

### Step 2: Create/Find Web Service Key
1. If you don't have a Web Service key:
   - Click "Create New Key"
   - Name: "Feng Shui Backend"
   - Service: Select "**Web Service API**" (not Web JS)
   - Click Create

2. If you already have keys:
   - Look for a key with "Web Service" type
   - Copy the key value

### Step 3: Update Backend Configuration

Edit `backend/.env` file:
```
AMAP_API_KEY=YOUR_WEB_SERVICE_KEY_HERE
AMAP_SECURITY_KEY=not_needed_for_web_service
```

**Note:** Web Service API keys don't need a security key (that's only for Web JS API).

---

## Quick Fix: Use Demo Mode (For Testing Only)

If you can't get real API keys right now, I can switch the system to **demo mode** with simulated data:

### Demo Mode Features:
- ✅ Different scores for different locations
- ✅ Realistic variations in green space, water, buildings
- ✅ Full system functionality
- ❌ Not using real map data (simulated based on coordinates)

Would you like me to:
1. **Wait for you to get Web Service API keys** (recommended for production)
2. **Enable demo mode now** (good for testing the frontend immediately)

---

## Testing After Configuration

After you update the `.env` file with your Web Service key:

```bash
# 1. Test the API key
cd backend
python test_amap_api.py

# 2. Restart backend
python app.py

# 3. Test multiple locations
python ../test_dynamic_scoring.py
```

You should see:
- ✅ POI search returns actual places
- ✅ Different locations have different scores
- ✅ Green space varies (high near parks, low downtown)
- ✅ Water element varies (high near lakes, low elsewhere)

---

## Why Two Different Key Types?

**Web JS API** (Frontend):
- Runs in browser
- Requires security key (jscode)
- Used for map display, user interaction
- Limited to frontend operations

**Web Service API** (Backend):
- Runs on server  
- No security key needed
- Used for POI search, geocoding, batch operations
- Full API access

---

**Current Status:**
- Frontend keys: ✅ Configured correctly
- Backend keys: ❌ Wrong type (using Web JS key instead of Web Service key)

Let me know which option you prefer!
